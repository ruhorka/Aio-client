package dev.aioclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Supplier;

/** Single settings screen: modules, look, performance presets. Opens with Right Shift or /aio. */
public class SettingsScreen extends Screen {
	private static final int BW = 122;
	private static final int BH = 20;
	private static final int GAP = 4;
	private static final int COLS = 3;

	private int labelOptionsY;
	private int labelPerfY;

	public SettingsScreen() {
		super(Text.literal("AIO Client"));
	}

	@Override
	protected void init() {
		int y = 28;

		// --- modules ---
		int i = 0;
		for (Module module : Module.values()) {
			add(i++, y, module.title, () -> Config.on(module) ? "ON" : "OFF", () -> Config.set(module, !Config.on(module)));
		}
		y += rows(Module.values().length) * (BH + GAP) + 14;

		// --- look ---
		labelOptionsY = y - 12;
		i = 0;
		add(i++, y, "Armor", () -> Config.I.armorVertical ? "Vertical" : "Horizontal",
			() -> toggle(() -> Config.I.armorVertical = !Config.I.armorVertical));
		add(i++, y, "Durability", () -> Config.I.armorPercent ? "Percent" : "Number",
			() -> toggle(() -> Config.I.armorPercent = !Config.I.armorPercent));
		add(i++, y, "Theme", () -> Config.ACCENT_NAMES[Math.floorMod(Config.I.theme, Config.ACCENT_NAMES.length)],
			() -> toggle(() -> Config.I.theme = (Config.I.theme + 1) % Config.ACCENTS.length));
		add(i++, y, "Panels", () -> Config.PANEL_NAMES[Math.floorMod(Config.I.panel, Config.PANEL_NAMES.length)],
			() -> toggle(() -> Config.I.panel = (Config.I.panel + 1) % Config.PANELS.length));
		add(i++, y, "Hotbar numbers", () -> Config.I.hotbarNumbers ? "ON" : "OFF",
			() -> toggle(() -> Config.I.hotbarNumbers = !Config.I.hotbarNumbers));
		add(i++, y, "Hotbar grid", () -> Config.I.hotbarGrid ? "ON" : "OFF",
			() -> toggle(() -> Config.I.hotbarGrid = !Config.I.hotbarGrid));
		y += rows(i) * (BH + GAP) + 14;

		// --- performance ---
		labelPerfY = y - 12;
		i = 0;
		for (Performance.Preset preset : Performance.Preset.values()) {
			addAction(i++, y, preset.title, () -> Performance.apply(preset));
		}
		addAction(i++, y, "Restore my settings", Performance::restore);
		y += rows(i) * (BH + GAP) + 6;

		// --- done ---
		addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> close())
			.dimensions(width / 2 - 100, y, 200, BH).build());
	}

	private static int rows(int count) {
		return (count + COLS - 1) / COLS;
	}

	private static void toggle(Runnable change) {
		change.run();
		Config.save();
	}

	private int x(int index) {
		int total = COLS * BW + (COLS - 1) * GAP;
		return width / 2 - total / 2 + (index % COLS) * (BW + GAP);
	}

	private int y(int index, int baseY) {
		return baseY + (index / COLS) * (BH + GAP);
	}

	/** A button whose label is "Name: value" and refreshes after every click. */
	private void add(int index, int baseY, String name, Supplier<String> value, Runnable action) {
		addDrawableChild(ButtonWidget.builder(Text.literal(name + ": " + value.get()), button -> {
			action.run();
			button.setMessage(Text.literal(name + ": " + value.get()));
		}).dimensions(x(index), y(index, baseY), BW, BH).build());
	}

	/** A plain action button. */
	private void addAction(int index, int baseY, String name, Runnable action) {
		addDrawableChild(ButtonWidget.builder(Text.literal(name), button -> action.run())
			.dimensions(x(index), y(index, baseY), BW, BH).build());
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		int accent = Config.accent();
		ctx.drawText(textRenderer, "AIO Client", width / 2 - textRenderer.getWidth("AIO Client") / 2, 10, accent, true);
		ctx.drawText(textRenderer, "Look", width / 2 - 186, labelOptionsY, 0xFFAAAAAA, true);
		ctx.drawText(textRenderer, "Performance (current: " + Config.I.lastPreset + ")", width / 2 - 186, labelPerfY, 0xFFAAAAAA, true);
	}
}
