package dev.aioclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class HudRenderer {
	private static final int WHITE = 0xFFFFFFFF;
	private static final int GRAY = 0xFFAAAAAA;
	private static final int GREEN = 0xFF55FF55;
	private static final int YELLOW = 0xFFFFFF55;
	private static final int RED = 0xFFFF5555;
	private static final int LINE_HEIGHT = 12;

	private static ItemStack[] counterIcons;

	private HudRenderer() {
	}

	public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
		MinecraftClient mc = MinecraftClient.getInstance();
		ClientPlayerEntity player = mc.player;
		if (player == null || mc.options.hudHidden || !Config.on(Module.HUD)) {
			return;
		}
		TextRenderer tr = mc.textRenderer;
		int w = ctx.getScaledWindowWidth();
		int h = ctx.getScaledWindowHeight();

		drawInfoColumn(ctx, tr, mc, player);
		if (Config.on(Module.ARMOR)) {
			drawArmor(ctx, tr, player, w, h);
		}
		if (Config.on(Module.ITEMS)) {
			drawCounters(ctx, tr, player, h);
		}
		if (Config.on(Module.TARGET)) {
			drawTarget(ctx, tr, player, w, h);
		}
		if (Config.on(Module.HOTBAR) && !player.isSpectator()) {
			drawHotbar(ctx, tr, w, h);
		}
		if (Config.on(Module.CROSSHAIR)) {
			drawCooldownRing(ctx, player, w, h);
		}
		if (Config.on(Module.DAMAGE)) {
			drawDamage(ctx, tr, w, h);
		}
	}

	// ---------- shared drawing helpers ----------

	private static void panel(DrawContext ctx, int x1, int y1, int x2, int y2) {
		int color = Config.panelColor();
		if ((color >>> 24) != 0) {
			ctx.fill(x1, y1, x2, y2, color);
		}
	}

	private static int line(DrawContext ctx, TextRenderer tr, String text, int x, int y, int color) {
		panel(ctx, x - 2, y - 2, x + tr.getWidth(text) + 2, y + 10);
		ctx.fill(x - 2, y - 2, x - 1, y + 10, Config.accent());
		ctx.drawText(tr, text, x, y, color, true);
		return y + LINE_HEIGHT;
	}

	private static int ratioColor(float ratio) {
		return ratio > 0.5f ? GREEN : ratio > 0.25f ? YELLOW : RED;
	}

	// ---------- top-left column ----------

	private static void drawInfoColumn(DrawContext ctx, TextRenderer tr, MinecraftClient mc, ClientPlayerEntity player) {
		int x = 5;
		int y = 4;

		if (Config.on(Module.STATS)) {
			y = line(ctx, tr, "FPS: " + mc.getCurrentFps(), x, y, WHITE);
			int ping = ping(mc);
			y = line(ctx, tr, "Ping: " + ping + " ms", x, y, ping < 80 ? GREEN : ping < 150 ? YELLOW : RED);
		}
		if (Config.on(Module.COORDS)) {
			y = line(ctx, tr, "XYZ: " + player.getBlockX() + " " + player.getBlockY() + " " + player.getBlockZ(), x, y, WHITE);
		}
		if (Config.on(Module.CPS)) {
			y = line(ctx, tr, "CPS: " + CombatTracker.leftCps() + " | " + CombatTracker.rightCps(), x, y, WHITE);
		}
		if (Config.on(Module.COMBAT)) {
			y = line(ctx, tr, "Combo: " + CombatTracker.combo(), x, y, CombatTracker.combo() >= 3 ? GREEN : WHITE);
			double reach = CombatTracker.reach();
			String reachText = reach < 0 ? "Reach: -" : String.format(Locale.ROOT, "Reach: %.2f", reach);
			y = line(ctx, tr, reachText, x, y, WHITE);
		}
		if (Config.on(Module.POTIONS)) {
			List<StatusEffectInstance> effects = new ArrayList<>(player.getStatusEffects());
			effects.sort((a, b) -> Integer.compare(b.getDuration(), a.getDuration()));
			if (!effects.isEmpty()) {
				y += 4;
			}
			for (StatusEffectInstance effect : effects) {
				String name = effect.getEffectType().value().getName().getString();
				if (effect.getAmplifier() > 0) {
					name += " " + roman(effect.getAmplifier() + 1);
				}
				String time = effect.isInfinite() ? "**:**" : formatTime(effect.getDuration());
				StatusEffectCategory category = effect.getEffectType().value().getCategory();
				int color = category == StatusEffectCategory.HARMFUL ? RED : category == StatusEffectCategory.BENEFICIAL ? GREEN : WHITE;
				if (!effect.isInfinite() && effect.getDuration() < 200) {
					color = YELLOW;
				}
				y = line(ctx, tr, name + " " + time, x, y, color);
			}
		}
	}

	private static int ping(MinecraftClient mc) {
		ClientPlayNetworkHandler handler = mc.getNetworkHandler();
		if (handler == null || mc.player == null) {
			return 0;
		}
		PlayerListEntry entry = handler.getPlayerListEntry(mc.player.getUuid());
		return entry == null ? 0 : entry.getLatency();
	}

	// ---------- armor HUD (vertical on the right or horizontal above the hotbar) ----------

	private static void drawArmor(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int w, int h) {
		ItemStack[] stacks = {
			player.getEquippedStack(EquipmentSlot.HEAD),
			player.getEquippedStack(EquipmentSlot.CHEST),
			player.getEquippedStack(EquipmentSlot.LEGS),
			player.getEquippedStack(EquipmentSlot.FEET),
			player.getMainHandStack()
		};
		boolean vertical = Config.I.armorVertical;
		int x = vertical ? w - 22 : w / 2 - 50;
		int y = vertical ? h / 2 - 50 : h - 88;

		for (ItemStack stack : stacks) {
			if (!stack.isEmpty()) {
				ctx.drawItem(stack, x, y);
				if (stack.isDamageable()) {
					int left = stack.getMaxDamage() - stack.getDamage();
					float ratio = left / (float) stack.getMaxDamage();
					String text = Config.I.armorPercent ? Math.round(ratio * 100) + "%" : String.valueOf(left);
					int color = ratioColor(ratio);
					if (vertical) {
						ctx.drawText(tr, text, x - 3 - tr.getWidth(text), y + 4, color, true);
					} else {
						ctx.drawText(tr, text, x + 8 - tr.getWidth(text) / 2, y + 17, color, true);
					}
				}
			}
			if (vertical) {
				y += 20;
			} else {
				x += 20;
			}
		}
	}

	// ---------- item counters (left side) ----------

	private static void drawCounters(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int h) {
		if (counterIcons == null) {
			counterIcons = new ItemStack[] {
				new ItemStack(Items.TOTEM_OF_UNDYING),
				new ItemStack(Items.END_CRYSTAL),
				new ItemStack(Items.GOLDEN_APPLE),
				new ItemStack(Items.ENDER_PEARL)
			};
		}
		int[] counts = {
			count(player, Items.TOTEM_OF_UNDYING),
			count(player, Items.END_CRYSTAL),
			count(player, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE),
			count(player, Items.ENDER_PEARL)
		};
		int x = 4;
		int y = h / 2 - 30;
		for (int i = 0; i < counterIcons.length; i++) {
			ctx.drawItem(counterIcons[i], x, y);
			int color = (i == 0 && counts[i] == 0) ? RED : WHITE; // no totem left -> red
			ctx.drawText(tr, "x" + counts[i], x + 20, y + 4, color, true);
			y += 18;
		}
	}

	private static int count(PlayerEntity player, Item... items) {
		int total = 0;
		PlayerInventory inventory = player.getInventory();
		int slots = Math.min(inventory.size(), 36); // hotbar + main inventory
		for (int i = 0; i < slots; i++) {
			total += countIn(inventory.getStack(i), items);
		}
		return total + countIn(player.getOffHandStack(), items);
	}

	private static int countIn(ItemStack stack, Item[] items) {
		for (Item item : items) {
			if (stack.isOf(item)) {
				return stack.getCount();
			}
		}
		return 0;
	}

	// ---------- target HUD ----------

	private static void drawTarget(DrawContext ctx, TextRenderer tr, ClientPlayerEntity player, int w, int h) {
		LivingEntity target = CombatTracker.target();
		if (target == null) {
			return;
		}
		float hp = target.getHealth();
		float max = Math.max(1f, target.getMaxHealth());
		float absorption = target.getAbsorptionAmount();

		int boxWidth = 120;
		int x = w / 2 - boxWidth / 2;
		int y = h / 2 + 26;

		panel(ctx, x - 4, y - 4, x + boxWidth + 4, y + 34);
		ctx.fill(x - 4, y - 4, x + boxWidth + 4, y - 3, Config.accent());
		ctx.drawText(tr, target.getName().getString(), x, y, WHITE, true);

		boolean winning = player.getHealth() + player.getAbsorptionAmount() >= hp + absorption;
		String status = winning ? "Winning" : "Losing";
		ctx.drawText(tr, status, x + boxWidth - tr.getWidth(status), y, winning ? GREEN : RED, true);

		int barY = y + 12;
		float ratio = Math.max(0f, Math.min(1f, hp / max));
		ctx.fill(x, barY, x + boxWidth, barY + 6, 0xFF333333);
		ctx.fill(x, barY, x + (int) (boxWidth * ratio), barY + 6, ratioColor(ratio));

		String text = String.format(Locale.ROOT, "%.1f / %.1f", hp, max);
		if (absorption > 0) {
			text += String.format(Locale.ROOT, "  +%.1f", absorption);
		}
		ctx.drawText(tr, text, x, barY + 9, GRAY, true);
	}

	// ---------- hotbar: slot numbers + grid ----------

	private static void drawHotbar(DrawContext ctx, TextRenderer tr, int w, int h) {
		int left = w / 2 - 91;
		if (Config.I.hotbarGrid) {
			int grid = (0x40 << 24) | (Config.accent() & 0xFFFFFF);
			for (int i = 1; i < 9; i++) {
				ctx.fill(left + i * 20, h - 21, left + i * 20 + 1, h - 1, grid);
			}
		}
		if (Config.I.hotbarNumbers) {
			for (int i = 0; i < 9; i++) {
				ctx.drawText(tr, String.valueOf(i + 1), left + i * 20 + 3, h - 20, GRAY, true);
			}
		}
	}

	// ---------- crosshair: attack cooldown ring ----------

	private static void drawCooldownRing(DrawContext ctx, ClientPlayerEntity player, int w, int h) {
		float progress = player.getAttackCooldownProgress(0.0f);
		if (progress >= 1.0f) {
			return; // only visible while the weapon is recharging
		}
		int cx = w / 2;
		int cy = h / 2;
		int segments = 40;
		int radius = 9;
		int accent = Config.accent();
		for (int i = 0; i < segments; i++) {
			double angle = -Math.PI / 2 + i * (2 * Math.PI / segments);
			int px = cx + (int) Math.round(Math.cos(angle) * radius);
			int py = cy + (int) Math.round(Math.sin(angle) * radius);
			boolean filled = (i + 1) / (float) segments <= progress;
			ctx.fill(px - 1, py - 1, px + 1, py + 1, filled ? accent : 0x55FFFFFF);
		}
	}

	// ---------- floating damage numbers (only damage dealt by you) ----------

	private static void drawDamage(DrawContext ctx, TextRenderer tr, int w, int h) {
		long now = System.currentTimeMillis();
		for (CombatTracker.DamageNumber number : CombatTracker.damages()) {
			long age = now - number.time;
			if (age < 0 || age > 900) {
				continue;
			}
			float t = age / 900f;
			int alpha = Math.max(16, (int) (255 * (1f - t)));
			int x = w / 2 + 14 + (int) (number.time % 3) * 16;
			int y = h / 2 - 14 - (int) (t * 24);
			ctx.drawText(tr, String.format(Locale.ROOT, "-%.1f", number.amount), x, y, (alpha << 24) | 0xFF5555, true);
		}
	}

	// ---------- formatting ----------

	private static String formatTime(int ticks) {
		int seconds = Math.max(0, ticks / 20);
		int s = seconds % 60;
		return (seconds / 60) + ":" + (s < 10 ? "0" : "") + s;
	}

	private static String roman(int n) {
		String[] numerals = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
		return n >= 1 && n < numerals.length ? numerals[n] : String.valueOf(n);
	}
}
