package dev.aioclient;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

/** Observes your own actions only: CPS, combo, reach, current target and damage you dealt. */
public final class CombatTracker {
	public static final class DamageNumber {
		public final float amount;
		public final long time;

		DamageNumber(float amount, long time) {
			this.amount = amount;
			this.time = time;
		}
	}

	private static final ArrayDeque<Long> LEFT_CLICKS = new ArrayDeque<>();
	private static final ArrayDeque<Long> RIGHT_CLICKS = new ArrayDeque<>();
	private static final ArrayDeque<DamageNumber> DAMAGES = new ArrayDeque<>();
	private static boolean leftDown;
	private static boolean rightDown;

	private static int combo;
	private static double lastReach = -1;
	private static LivingEntity target;
	private static long targetTime;
	private static long lastAttackTime;
	private static long lastComboHit;
	private static int lastTargetHurt;
	private static int lastSelfHurt;
	private static float lastTargetHealth;

	private CombatTracker() {
	}

	public static void init() {
		ClientTickEvents.END_CLIENT_TICK.register(CombatTracker::tick);
		AttackEntityCallback.EVENT.register(CombatTracker::onAttack);
	}

	public static int leftCps() {
		return LEFT_CLICKS.size();
	}

	public static int rightCps() {
		return RIGHT_CLICKS.size();
	}

	public static int combo() {
		return combo;
	}

	/** Reach of the last attack in blocks, or -1 when there was no attack in the last 5 seconds. */
	public static double reach() {
		return System.currentTimeMillis() - lastAttackTime < 5000 ? lastReach : -1;
	}

	public static LivingEntity target() {
		return target;
	}

	/** Recent damage numbers (newest last). Safe copy, called once per frame. */
	public static List<DamageNumber> damages() {
		return new ArrayList<>(DAMAGES);
	}

	private static ActionResult onAttack(PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hit) {
		if (!world.isClient()) {
			return ActionResult.PASS;
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		if (player != mc.player || !(entity instanceof LivingEntity living)) {
			return ActionResult.PASS;
		}

		long now = System.currentTimeMillis();
		if (living != target) {
			combo = 0;
		}
		lastReach = hit != null ? player.getEyePos().distanceTo(hit.getPos()) : player.distanceTo(entity);
		target = living;
		targetTime = now;
		lastAttackTime = now;
		lastTargetHurt = living.hurtTime;
		lastTargetHealth = living.getHealth() + living.getAbsorptionAmount();
		return ActionResult.PASS;
	}

	private static void tick(MinecraftClient mc) {
		ClientPlayerEntity player = mc.player;
		if (player == null || mc.world == null) {
			reset();
			return;
		}
		long now = System.currentTimeMillis();

		// CPS: rising edges of the attack / use keys (accurate up to 20 clicks per second)
		boolean left = mc.currentScreen == null && mc.options.attackKey.isPressed();
		boolean right = mc.currentScreen == null && mc.options.useKey.isPressed();
		if (left && !leftDown) {
			LEFT_CLICKS.addLast(now);
		}
		if (right && !rightDown) {
			RIGHT_CLICKS.addLast(now);
		}
		leftDown = left;
		rightDown = right;
		prune(LEFT_CLICKS, now);
		prune(RIGHT_CLICKS, now);

		if (target != null) {
			// Combo: +1 when the target starts its hurt animation right after our attack
			int hurt = target.hurtTime;
			if (hurt > lastTargetHurt && now - lastAttackTime < 600) {
				combo++;
				lastComboHit = now;
			}
			lastTargetHurt = hurt;

			// Damage numbers: only health lost shortly after OUR attack (not lava, not other players)
			float health = target.getHealth() + target.getAbsorptionAmount();
			if (health < lastTargetHealth - 0.01f && now - lastAttackTime < 800) {
				DAMAGES.addLast(new DamageNumber(lastTargetHealth - health, now));
			}
			lastTargetHealth = health;

			if (target.isRemoved() || !target.isAlive() || now - targetTime > 5000) {
				target = null;
			}
		}
		while (!DAMAGES.isEmpty() && now - DAMAGES.peekFirst().time > 1000) {
			DAMAGES.pollFirst();
		}

		// Combo resets when we take damage or nothing was hit for 3 seconds
		int selfHurt = player.hurtTime;
		if (selfHurt > lastSelfHurt) {
			combo = 0;
		}
		lastSelfHurt = selfHurt;
		if (combo > 0 && now - lastComboHit > 3000) {
			combo = 0;
		}
	}

	private static void prune(ArrayDeque<Long> clicks, long now) {
		while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) {
			clicks.pollFirst();
		}
	}

	private static void reset() {
		LEFT_CLICKS.clear();
		RIGHT_CLICKS.clear();
		DAMAGES.clear();
		leftDown = false;
		rightDown = false;
		combo = 0;
		target = null;
		lastReach = -1;
		lastSelfHurt = 0;
		lastTargetHurt = 0;
	}
}
