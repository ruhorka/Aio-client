package dev.aioclient;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AioClient implements ClientModInitializer {
	public static final String MOD_ID = "aioclient";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	private static KeyBinding menuKey;
	private static KeyBinding toggleKey;

	@Override
	public void onInitializeClient() {
		Config.load();
		CombatTracker.init();

		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of(MOD_ID, "hud"), HudRenderer::render);

		// Keys (rebind in Controls)
		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of(MOD_ID, "main"));
		menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.aioclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
		toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
			"key.aioclient.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, category));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (menuKey.wasPressed()) {
				client.setScreen(new SettingsScreen());
			}
			while (toggleKey.wasPressed()) {
				boolean value = !Config.on(Module.HUD);
				Config.set(Module.HUD, value);
				if (client.player != null) {
					client.player.sendMessage(Text.literal("HUD: " + (value ? "ON" : "OFF")), true);
				}
			}
		});

		// Commands:  /aio  (settings)   /aio <module>  (toggle)   /aio perf <balanced|performance|maxfps|restore>
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
			LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("aio");
			root.executes(context -> {
				MinecraftClient mc = MinecraftClient.getInstance();
				mc.send(() -> mc.setScreen(new SettingsScreen())); // next tick, after the chat screen closes
				return 1;
			});
			for (Module module : Module.values()) {
				root.then(ClientCommandManager.literal(module.id).executes(context -> {
					boolean value = !Config.on(module);
					Config.set(module, value);
					context.getSource().sendFeedback(Text.literal(module.title + ": " + (value ? "ON" : "OFF")));
					return 1;
				}));
			}
			LiteralArgumentBuilder<FabricClientCommandSource> perf = ClientCommandManager.literal("perf");
			for (Performance.Preset preset : Performance.Preset.values()) {
				perf.then(ClientCommandManager.literal(preset.key).executes(context -> {
					Performance.apply(preset);
					context.getSource().sendFeedback(Text.literal("Preset: " + preset.title));
					return 1;
				}));
			}
			perf.then(ClientCommandManager.literal("restore").executes(context -> {
				boolean ok = Performance.restore();
				context.getSource().sendFeedback(Text.literal(ok ? "Video settings restored" : "Nothing to restore"));
				return 1;
			}));
			root.then(perf);
			dispatcher.register(root);
		});

		LOGGER.info("AIO Client loaded");
	}
}
