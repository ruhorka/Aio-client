package dev.aioclient;

/** Everything that can be switched on/off. Command id: /aio <id>. */
public enum Module {
	HUD("hud", "HUD (master)"),
	ARMOR("armor", "Armor HUD"),
	POTIONS("potions", "Potion effects"),
	STATS("stats", "FPS / Ping"),
	COORDS("coords", "Coordinates"),
	CPS("cps", "CPS counter"),
	COMBAT("combat", "Combo / Reach"),
	ITEMS("items", "Item counters"),
	TARGET("target", "Target HUD"),
	HOTBAR("hotbar", "Hotbar tweaks"),
	CROSSHAIR("crosshair", "Cooldown ring"),
	DAMAGE("damage", "Damage numbers");

	public final String id;
	public final String title;

	Module(String id, String title) {
		this.id = id;
		this.title = title;
	}
}
