package dev.aioclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;

import java.util.Map;

/**
 * One-click performance presets. They only change normal vanilla video options
 * (render/simulation distance, particles, entity distance, biome blend) and can be undone.
 * For real engine-level optimisation use Sodium / Lithium / FerriteCore together with this mod.
 */
public final class Performance {
	public enum Preset {
		BALANCED("balanced", "Balanced", 12, 8, "DECREASED", 1.0, 2),
		PERFORMANCE("performance", "Performance", 8, 6, "DECREASED", 0.75, 1),
		MAX_FPS("maxfps", "Max FPS", 6, 5, "MINIMAL", 0.5, 0);

		public final String key;
		public final String title;
		final int view;
		final int simulation;
		final String particles; // enum constant name, looked up at runtime
		final double entityScale;
		final int blend;

		Preset(String key, String title, int view, int simulation, String particles, double entityScale, int blend) {
			this.key = key;
			this.title = title;
			this.view = view;
			this.simulation = simulation;
			this.particles = particles;
			this.entityScale = entityScale;
			this.blend = blend;
		}
	}

	private Performance() {
	}

	public static void apply(Preset preset) {
		GameOptions o = MinecraftClient.getInstance().options;

		// remember the player's own settings once, so "Restore" brings them back
		Map<String, String> backup = Config.I.backup;
		if (backup.isEmpty()) {
			backup.put("view", String.valueOf(o.getViewDistance().getValue()));
			backup.put("sim", String.valueOf(o.getSimulationDistance().getValue()));
			backup.put("particles", particlesName(o));
			backup.put("entity", String.valueOf(o.getEntityDistanceScaling().getValue()));
			backup.put("blend", String.valueOf(o.getBiomeBlendRadius().getValue()));
		}

		o.getViewDistance().setValue(preset.view);
		o.getSimulationDistance().setValue(preset.simulation);
		setParticles(o, preset.particles);
		o.getEntityDistanceScaling().setValue(preset.entityScale);
		o.getBiomeBlendRadius().setValue(preset.blend);
		o.write();

		Config.I.lastPreset = preset.title;
		Config.save();
	}

	public static boolean restore() {
		Map<String, String> backup = Config.I.backup;
		if (backup.isEmpty()) {
			return false;
		}
		try {
			GameOptions o = MinecraftClient.getInstance().options;
			o.getViewDistance().setValue(Integer.parseInt(backup.get("view")));
			o.getSimulationDistance().setValue(Integer.parseInt(backup.get("sim")));
			setParticles(o, backup.get("particles"));
			o.getEntityDistanceScaling().setValue(Double.parseDouble(backup.get("entity")));
			o.getBiomeBlendRadius().setValue(Integer.parseInt(backup.get("blend")));
			o.write();
		} catch (Exception e) {
			AioClient.LOGGER.warn("Could not restore video settings", e);
			return false;
		}
		backup.clear();
		Config.I.lastPreset = "none";
		Config.save();
		return true;
	}

	// The particles option is an enum (ALL / DECREASED / MINIMAL). It is handled by name through
	// reflection so the code does not depend on which package that enum lives in.
	private static String particlesName(GameOptions o) {
		Object value = o.getParticles().getValue();
		return value instanceof Enum<?> e ? e.name() : "ALL";
	}

	@SuppressWarnings({"unchecked", "rawtypes"})
	private static void setParticles(GameOptions o, String name) {
		SimpleOption option = o.getParticles();
		Object current = option.getValue();
		if (!(current instanceof Enum<?> e)) {
			return;
		}
		for (Object constant : e.getDeclaringClass().getEnumConstants()) {
			if (((Enum<?>) constant).name().equals(name)) {
				option.setValue(constant);
				return;
			}
		}
		AioClient.LOGGER.warn("Unknown particles mode: {}", name);
	}
}
