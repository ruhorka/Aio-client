package dev.aioclient;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Saved to config/aioclient.json. Public fields are the settings. */
public final class Config {
	public static final int[] ACCENTS = {0xFF55AAFF, 0xFF55FF55, 0xFFFF5555, 0xFFAA66FF, 0xFFFFFFFF};
	public static final String[] ACCENT_NAMES = {"Blue", "Green", "Red", "Purple", "White"};
	public static final int[] PANELS = {0x00000000, 0x50000000, 0xB4000000};
	public static final String[] PANEL_NAMES = {"Off", "Glass", "Solid"};

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public static Config I = new Config();

	// modules
	public boolean hud = true;
	public boolean armor = true;
	public boolean potions = true;
	public boolean stats = true;
	public boolean coords = false;
	public boolean cps = true;
	public boolean combat = true;
	public boolean items = true;
	public boolean target = true;
	public boolean hotbar = true;
	public boolean crosshair = true;
	public boolean damage = true;

	// options
	public boolean armorVertical = true;
	public boolean armorPercent = false;
	public boolean hotbarNumbers = true;
	public boolean hotbarGrid = true;
	public int theme = 0;
	public int panel = 1;

	// performance presets
	public String lastPreset = "none";
	public Map<String, String> backup = new HashMap<>();

	public static int accent() {
		return ACCENTS[Math.floorMod(I.theme, ACCENTS.length)];
	}

	public static int panelColor() {
		return PANELS[Math.floorMod(I.panel, PANELS.length)];
	}

	public static boolean on(Module module) {
		Config c = I;
		return switch (module) {
			case HUD -> c.hud;
			case ARMOR -> c.armor;
			case POTIONS -> c.potions;
			case STATS -> c.stats;
			case COORDS -> c.coords;
			case CPS -> c.cps;
			case COMBAT -> c.combat;
			case ITEMS -> c.items;
			case TARGET -> c.target;
			case HOTBAR -> c.hotbar;
			case CROSSHAIR -> c.crosshair;
			case DAMAGE -> c.damage;
		};
	}

	public static void set(Module module, boolean value) {
		Config c = I;
		switch (module) {
			case HUD -> c.hud = value;
			case ARMOR -> c.armor = value;
			case POTIONS -> c.potions = value;
			case STATS -> c.stats = value;
			case COORDS -> c.coords = value;
			case CPS -> c.cps = value;
			case COMBAT -> c.combat = value;
			case ITEMS -> c.items = value;
			case TARGET -> c.target = value;
			case HOTBAR -> c.hotbar = value;
			case CROSSHAIR -> c.crosshair = value;
			case DAMAGE -> c.damage = value;
		}
		save();
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("aioclient.json");
	}

	public static void load() {
		Path file = file();
		if (Files.exists(file)) {
			try (Reader reader = Files.newBufferedReader(file)) {
				Config loaded = GSON.fromJson(reader, Config.class);
				if (loaded != null) {
					I = loaded;
				}
			} catch (Exception e) {
				AioClient.LOGGER.warn("Could not read aioclient.json, using defaults", e);
			}
		}
		if (I.backup == null) {
			I.backup = new HashMap<>();
		}
		save();
	}

	public static void save() {
		try (Writer writer = Files.newBufferedWriter(file())) {
			GSON.toJson(I, writer);
		} catch (Exception e) {
			AioClient.LOGGER.warn("Could not save aioclient.json", e);
		}
	}
}
