# AIO Client (Fabric, Minecraft 1.21.11)

Всё в одном клиентском моде: PvP-HUD, быстрые пресеты производительности, темы и экран настроек.
Без IRC, без читов, ничего не отправляется на сервер.

## Сборка (Java 21)
1. В папке проекта: `gradle wrapper --gradle-version 9.2.1` (нужен установленный Gradle)
2. `./gradlew build` (Windows: `gradlew.bat build`)
3. Jar: `build/libs/aioclient-1.0.0.jar` (не `-sources`). Кинь в `mods` вместе с Fabric API.
Тест из среды разработки: `./gradlew runClient`.

## Управление
- Right Shift: экран настроек (меняется в Управлении)
- H: вкл/выкл весь HUD
- `/aio` - экран настроек
- `/aio <hud|armor|potions|stats|coords|cps|combat|items|target|hotbar|crosshair|damage>` - вкл/выкл модуль
- `/aio perf <balanced|performance|maxfps|restore>` - пресеты производительности
- Настройки: `config/aioclient.json`

## Про производительность
Пресеты меняют обычные настройки видео (дальность прорисовки и симуляции, частицы, дистанцию сущностей,
смешивание биомов) и умеют вернуть твои исходные значения кнопкой Restore.
Для настоящей оптимизации движка ставь рядом Sodium, Lithium, FerriteCore - с ними мод совместим.
