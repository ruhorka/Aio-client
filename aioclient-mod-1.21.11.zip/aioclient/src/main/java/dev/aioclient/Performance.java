package dev.aioclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;

import java.util.Map;

/**
 * One-click performance presets. They only change normal vanilla video options
 * (render/simulation distance, particles, entity distance, biome blend) and can be undone.
 * For real engine-level optimisation use Sodium / Lithium / FerriteCore together with this mod.
 */
public final class Performance {
	public enum Preset {
		BALANCED("balanced", "Balanced", 12, 8, ParticlesMode.DECREASED, 1.0, 2),
		PERFORMANCE("performance", "Performance", 8, 6, ParticlesMode.DECREASED, 0.75, 1),
		MAX_FPS("maxfps", "Max FPS", 6, 5, ParticlesMode.MINIMAL, 0.5, 0);

		public final String key;
		public final String title;
		final int view;
		final int simulation;
		final ParticlesMode particles;
		final double entityScale;
		final int blend;

		Preset(String key, String title, int view, int simulation, ParticlesMode particles, double entityScale, int blend) {
			this.key = key;
			this.title = title;
			this.view = view;
			this.simulation = simulation;
			this.particles = particles;
			this.entityScale = entityScale;
			this.blend = blend;
		}
	}

	private Performance() {
	}

	public static void apply(Preset preset) {
		MinecraftClient mc = MinecraftClient.getInstance();
		GameOptions o = mc.options;

		// remember the player's own settings once, so "Restore" brings them back
		Map<String, String> backup = Config.I.backup;
		if (backup.isEmpty()) {
			backup.put("view", String.valueOf(o.getViewDistance().getValue()));
			backup.put("sim", String.valueOf(o.getSimulationDistance().getValue()));
			backup.put("particles", o.getParticles().getValue().name());
			backup.put("entity", String.valueOf(o.getEntityDistanceScaling().getValue()));
			backup.put("blend", String.valueOf(o.getBiomeBlendRadius().getValue()));
		}

		o.getViewDistance().setValue(preset.view);
		o.getSimulationDistance().setValue(preset.simulation);
		o.getParticles().setValue(preset.particles);
		o.getEntityDistanceScaling().setValue(preset.entityScale);
		o.getBiomeBlendRadius().setValue(preset.blend);
		o.write();

		Config.I.lastPreset = preset.title;
		Config.save();
	}

	public static boolean restore() {
		Map<String, String> backup = Config.I.backup;
		if (backup.isEmpty()) {
			return false;
		}
		try {
			GameOptions o = MinecraftClient.getInstance().options;
			o.getViewDistance().setValue(Integer.parseInt(backup.get("view")));
			o.getSimulationDistance().setValue(Integer.parseInt(backup.get("sim")));
			o.getParticles().setValue(ParticlesMode.valueOf(backup.get("particles")));
			o.getEntityDistanceScaling().setValue(Double.parseDouble(backup.get("entity")));
			o.getBiomeBlendRadius().setValue(Integer.parseInt(backup.get("blend")));
			o.write();
		} catch (Exception e) {
			AioClient.LOGGER.warn("Could not restore video settings", e);
			return false;
		}
		backup.clear();
		Config.I.lastPreset = "none";
		Config.save();
		return true;
	}
}
